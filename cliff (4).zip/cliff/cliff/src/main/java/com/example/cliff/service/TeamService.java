package com.example.cliff.service;


import com.example.cliff.dto.TeamDTO;
import com.example.cliff.entity.Team;

public interface TeamService {
	
	public Team createTeam(TeamDTO teamDto);
	/*
	 * public Team getTeam(int id); public void deleteTeam(Team team); public
	 * boolean updateTeam(Team team);
	 */
	
	

}
