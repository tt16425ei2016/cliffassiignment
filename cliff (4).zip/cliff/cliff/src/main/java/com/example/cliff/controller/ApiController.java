package com.example.cliff.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.cliff.dto.PlayerDTO;
import com.example.cliff.dto.TeamDTO;
import com.example.cliff.entity.Player;
import com.example.cliff.entity.Team;
import com.example.cliff.service.PlayerServiceImpl;
import com.example.cliff.service.TeamServiceImpl;

@RestController
@RequestMapping("/cliff")
public class ApiController {
	
	@Autowired
	private PlayerServiceImpl playerServiceImpl;
	@Autowired
	private TeamServiceImpl teamServiceImpl;
	
	
	
	  @PostMapping("/createTeam")
	  public Team createTeam(@RequestBody TeamDTO teamDto)
	  { 
	  	return teamServiceImpl.createTeam(teamDto);
	  
	  }
	 
	
	
	
	 @PostMapping("/createPlayer") public Player createPlayer(@RequestBody
	  PlayerDTO playerDto) { 
		 
		 return playerServiceImpl.createPlayer(playerDto);
	  
	  }
	 
	  
	  
	  @GetMapping("/getTeam/{id}") 
	  public Team findTeamById(@PathVariable int id) { 
		  return teamServiceImpl.getTeam(id); }
	 
	  
	  @GetMapping("/getPlayer/{id}") 
	  public Player findPlayerById(@PathVariable int id) { return
	  playerServiceImpl.getPlayer(id); }
	  
 
	  @DeleteMapping("/deleteTeam/{teamId}") 
	  public void deleteTeam(@PathVariable int teamId) {
	  teamServiceImpl.deleteTeam(teamId); }
	  
	 @DeleteMapping("/deletePlayer/{playerId}") 
	 public void deletePlayer(@PathVariable int playerId) {
	  playerServiceImpl.deletePlayer(playerId); }
	  
	  
	  @GetMapping("playersByTeamId") public List<Player> findPlayerByTeamId(int
	  id){
	  
	  return playerServiceImpl.findPlayersByTeamId(id); }
	  
	 /* @GetMapping("TeamByPlayerId") public Team findTeamByPlayerId(int id) { int
	 * teamId=playerServiceImpl.findTeamIdByPlayerId(id); return
	 * teamServiceImpl.getTeam(teamId); }
	 * 
	 * @GetMapping("getAllPlayers") public List<Player> getAllPlayers(){ return
	 * playerServiceImpl.getAllPlayers(); }
	 * 
	 * @GetMapping("getAllTeams") public List<Team> getAllTeams(){ return
	 * teamServiceImpl.findAllTeams(); }
	 * 
	 */
	 
}
