package com.example.cliff.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.cliff.dto.PlayerDTO;
import com.example.cliff.entity.Player;
import com.example.cliff.entity.Team;
import com.example.cliff.repository.PlayerRepo;
import com.example.cliff.repository.TeamRepo;

@Service
public class PlayerServiceImpl implements PlayerService {
	@Autowired
	PlayerRepo playerRepo;
	
	@Autowired
	TeamRepo teamRepo;

	public Player createPlayer(PlayerDTO playerDto) {
		Player player =new Player();
		player.setId(playerDto.getId());
		player.setName(playerDto.getName());
		player.setAge(playerDto.getAge());
		player.setCreatedAt(new Date());
		player.setUpdatedAt(new Date());
		//player.setTeamId(playerDto.getTeamId());
		
		//Team team=teamRepo.findById(playerDto.getTeamId()).get();
		
		
		
		  Team team=new Team();
		  team.setId(playerDto.getTeamId());
		 
		 /* team.setName(playerDto.getTeamId().getName());
		 * team.setLocation(player.getTeamId().getLocation());
		 * team.setCreatedAt(playerDto.getTeamId().getCreatedAt());
		 * team.setUpdatedAt(playerDto.getTeamId().getUpdatedAt());
		 * 
		 */ 
		  player.setTeam(team);
		 
		 
		return playerRepo.save(player);
		
	}

	public Player getPlayer(int id) {
		return playerRepo.findById(id).get();

	}

	public void deletePlayer(int playerId) {
		Player player = playerRepo.findById(playerId).get();
		playerRepo.delete(player);
	}

	// implementationleft
	public boolean updatePlayer(Player player) {
		Optional<Player> pl = playerRepo.findById(player.getId());
		if (pl.isEmpty()) {
			return false;
		} else {
			return true;
		}

	}

	public List<Player> findPlayersByTeamId(int id) {
		return null;
		// playerRepo.findPlayersByTeamId(id);
	}

	public int findTeamIdByPlayerId(int id) {
		return 0;
		// playerRepo.findTeamIdByPlayerId(id);
	}

	public List<Player> getAllPlayers() {
		return playerRepo.findAll();
	}
}
