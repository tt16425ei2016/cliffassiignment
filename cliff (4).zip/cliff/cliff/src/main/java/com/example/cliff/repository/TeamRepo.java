package com.example.cliff.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.cliff.entity.Team;



public interface TeamRepo extends JpaRepository<Team, Integer> {
	
	
}
