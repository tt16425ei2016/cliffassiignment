package com.example.cliff.service;

import com.example.cliff.dto.PlayerDTO;
import com.example.cliff.entity.Player;

public interface PlayerService {

	public Player createPlayer(PlayerDTO playerDto);
	public Player getPlayer(int id);
	public void deletePlayer(int playerId);
	public boolean updatePlayer(Player player);

	
}
