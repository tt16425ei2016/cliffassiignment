package com.example.cliff.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.cliff.dto.TeamDTO;
import com.example.cliff.entity.Team;
import com.example.cliff.repository.TeamRepo;

@Service
public class TeamServiceImpl implements TeamService {
	

	@Autowired
	TeamRepo teamRepo;
	
	public Team createTeam(TeamDTO teamDto) {
		Team team =new Team();
		team.setId(teamDto.getId());
		team.setName(teamDto.getName());
		team.setLocation(teamDto.getLocation());
		team.setCreatedAt(new Date());
		team.setUpdatedAt(new Date());
		
		teamRepo.save(team);
		return team;
	}
	
	public Team getTeam(int id) {
		
		Optional<Team> op=teamRepo.findById(id);
		return op.get();
	}
	
	public void deleteTeam(int teamId) {
		Team team=teamRepo.findById(teamId).get();
		teamRepo.delete(team);
	}
	
	public boolean updateTeam(Team team){
		Optional<Team> tm=teamRepo.findById(team.getId());
		if(tm.isEmpty()) {
			return false;
		}
		else {
			return true;
		}
	}
	public List<Team> findAllTeams(){
		return teamRepo.findAll();
	}
	
	
	

}
