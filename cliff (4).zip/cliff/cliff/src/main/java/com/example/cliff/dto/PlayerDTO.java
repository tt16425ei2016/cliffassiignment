package com.example.cliff.dto;

import java.util.Date;

import com.example.cliff.entity.Team;
import com.sun.istack.NotNull;


public class PlayerDTO {
	
	@NotNull
	private int id;
	private String name;
	private int age;
	private Date createdAt;
	private Date updatedAt;
	@NotNull
	private int teamId ;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public int getTeamId() {
		return teamId;
	}
	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}
	
	
	

	
	
	

}
