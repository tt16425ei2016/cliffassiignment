package com.example.cliff.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.cliff.entity.Player;


@Repository
public interface PlayerRepo extends JpaRepository<Player, Integer> {
	
	
	/*
	 * @Query("SELECT * FROM PLAYER P WHERE P.TEAM_ID=?1") public List<Player>
	 * findPlayersByTeamId(int id);
	 * 
	 * @Query("SELECT P.TEAM_ID FROM PLAYER P WHERE P.ID=?1") public int
	 * findTeamIdByPlayerId(int id);
	 */
	
}
